# INFOM_Final_Implementation
Project Title: OverBuff 2 basic implementation
Mauricio, Gian
Lo, Jacob

Overbuff2 is our personal take on the website of Overbuff; with it's own specialized views to cater to more casual players who want to know the simple things.
