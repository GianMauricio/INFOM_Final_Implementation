<?php
session_start();
?>

<!doctype html>
<html>

<head>
<meta charset = "utf-8">
<link rel="stylesheet" href="../CSSStuff/StyleSheet.css">
<title>Directory</title>
</head>

<body>
  <h1>Player Views</h1>
  <br>
  <p>To procceed to player rankings: <a href="http://localhost/SQLViews/PlayerProfiles/ProfileView.php">To Rankings View</a></p>
  <?php
    if(isset($_SESSION["PlayerName"])){
      echo "<p>To procceed to personal statistics: <a href='http://localhost/SQLViews/PlayerProfiles/SingleStatView.php'>To personal stats View</a></p>";
    }
  ?>

</body>

</html>
