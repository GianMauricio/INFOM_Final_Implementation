<?php
session_start();
?>

<!doctype html>
<html>

<head>
<meta charset = "utf-8">
<link rel="stylesheet" href="../CSSStuff/StyleSheet.css">
<title>Directory</title>
</head>

<body>
  <h1>User Views</h1>
  <br>
  <p>To view the list of all heroes: <a href="http://localhost/SQLViews/Heroes/HeroesView.php">To All Heroes View</a></p>
</body>

</html>
