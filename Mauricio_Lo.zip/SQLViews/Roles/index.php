<?php
session_start();
?>

<!doctype html>
<html>

<head>
<meta charset = "utf-8">
<link rel="stylesheet" href="../CSSStuff/StyleSheet.css">
<title>Directory</title>
</head>

<body>
  <h1>Role Views</h1>
  <br>
  <p>To view the list of all Roles: <a href="http://localhost/SQLViews/Roles/RolesView.php">To All Hero Roles</a></p>
</body>

</html>
